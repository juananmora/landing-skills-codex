---
name: PPTX Deck Builder
description: Builds branded PowerPoint presentations from structured outlines with automatic slide layout recommendations.
category: Productivity
sourceFamily: Copilot
maintainer: Productivity Guild
score: 79
securityStatus: Passed
validationStatus: Pending
lastReviewed: 2025-03-05
---

# PPTX Deck Builder

Builds branded PowerPoint presentations from structured outlines with automatic slide layout recommendations.

## Usage

Reference this skill in your agent configuration to activate it.

## Notes

This is a simulated demo package. Replace with real content before production use.
