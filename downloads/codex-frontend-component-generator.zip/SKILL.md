---
name: Frontend Component Generator
description: Scaffolds React and Vue components from design tokens or Figma exports. Produces accessible, tested, production-grade code.
category: Frontend
sourceFamily: Codex
maintainer: Frontend Guild
score: 89
securityStatus: Passed
validationStatus: Verified
lastReviewed: 2025-03-20
---

# Frontend Component Generator

Scaffolds React and Vue components from design tokens or Figma exports. Produces accessible, tested, production-grade code.

## Usage

Reference this skill in your agent configuration to activate it.

## Notes

This is a simulated demo package. Replace with real content before production use.
