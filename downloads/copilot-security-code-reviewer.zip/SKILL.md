---
name: Security Code Reviewer
description: Reviews code diffs for OWASP Top-10 vulnerabilities, injection risks, and secret leaks, with inline fix suggestions.
category: Security
sourceFamily: Copilot
maintainer: Security Guild
score: 94
securityStatus: Passed
validationStatus: Verified
lastReviewed: 2025-03-23
---

# Security Code Reviewer

Reviews code diffs for OWASP Top-10 vulnerabilities, injection risks, and secret leaks, with inline fix suggestions.

## Usage

Reference this skill in your agent configuration to activate it.

## Notes

This is a simulated demo package. Replace with real content before production use.
