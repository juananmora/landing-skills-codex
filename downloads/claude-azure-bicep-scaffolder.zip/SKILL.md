---
name: Azure Bicep Scaffolder
description: Scaffolds Azure Bicep infrastructure templates for common patterns including VMs, AKS, and App Services.
category: Azure
sourceFamily: Claude
maintainer: Cloud Infrastructure Team
score: 88
securityStatus: Passed
validationStatus: Verified
lastReviewed: 2025-03-18
---

# Azure Bicep Scaffolder

Scaffolds Azure Bicep infrastructure templates for common patterns including VMs, AKS, and App Services.

## Usage

Reference this skill in your agent configuration to activate it.

## Notes

This is a simulated demo package. Replace with real content before production use.
