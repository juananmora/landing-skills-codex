---
name: OpenAI Image Generator
description: Generates DALL-E images from natural language prompts with configurable aspect ratios, quality and style presets.
category: OpenAI
sourceFamily: Copilot
maintainer: Creative Tools Team
score: 74
securityStatus: Review
validationStatus: Pending
lastReviewed: 2025-02-28
---

# OpenAI Image Generator

Generates DALL-E images from natural language prompts with configurable aspect ratios, quality and style presets.

## Usage

Reference this skill in your agent configuration to activate it.

## Notes

This is a simulated demo package. Replace with real content before production use.
