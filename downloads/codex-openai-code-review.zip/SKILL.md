---
name: OpenAI Code Review
description: Performs automated code reviews using GPT-4, flagging security issues, style violations, and performance bottlenecks.
category: OpenAI
sourceFamily: Codex
maintainer: Platform Engineering
score: 92
securityStatus: Passed
validationStatus: Verified
lastReviewed: 2025-03-22
---

# OpenAI Code Review

Performs automated code reviews using GPT-4, flagging security issues, style violations, and performance bottlenecks.

## Usage

Reference this skill in your agent configuration to activate it.

## Notes

This is a simulated demo package. Replace with real content before production use.
