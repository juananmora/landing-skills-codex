# codex-openai-code-review

This is a simulated demo skill package for the Codex Skills Hub.

## Overview

This skill is part of the demonstration catalog and shows how skills are packaged and distributed.

## Usage

Download and extract this ZIP to use the skill in your environment.
