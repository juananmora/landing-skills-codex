---
name: Playwright Test Generator
description: Generates end-to-end Playwright tests from user stories and component specs. Supports TypeScript and Page Object Model patterns.
category: Testing
sourceFamily: Codex
maintainer: QA Platform
score: 87
securityStatus: Passed
validationStatus: Verified
lastReviewed: 2025-03-21
---

# Playwright Test Generator

Generates end-to-end Playwright tests from user stories and component specs. Supports TypeScript and Page Object Model patterns.

## Usage

Reference this skill in your agent configuration to activate it.

## Notes

This is a simulated demo package. Replace with real content before production use.
