---
name: DOCX Report Generator
description: Generates structured Word DOCX reports from data templates and markdown content with custom corporate styling.
category: Productivity
sourceFamily: Codex
maintainer: Productivity Guild
score: 83
securityStatus: Passed
validationStatus: Verified
lastReviewed: 2025-03-10
---

# DOCX Report Generator

Generates structured Word DOCX reports from data templates and markdown content with custom corporate styling.

## Usage

Reference this skill in your agent configuration to activate it.

## Notes

This is a simulated demo package. Replace with real content before production use.
